This plugin was contributed by the Blackboard Open LMS Product Development team. Blackboard is an education technology company
dedicated to bringing excellent online teaching to institutions across the globe.  We serve colleges and universities,
schools and organizations by supporting the software that educators use to manage and deliver instructional content to
learners in virtual classrooms.

For more information about installation, configuration and usage, please see http://docs.moodle.org/dev/Advanced_Forum
